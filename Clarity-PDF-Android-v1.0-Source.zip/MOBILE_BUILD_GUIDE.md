# Simplest phone-only method: upload one ZIP to GitHub

Do not extract the source ZIP and do not upload the project folders one by one.

You need these two downloads from ChatGPT:

1. `Clarity-PDF-Android-v1.0-Source.zip` — this is the only file uploaded to the repository.
2. `PASTE-IN-GITHUB-ACTIONS.yml` — open this file and copy its text once when creating the workflow.

## Step 1 — Create the repository

1. Open GitHub in Chrome on your phone.
2. Create a new **private** repository named `clarity-pdf-android`.
3. Keep **Add a README file** unticked.
4. Tap **Create repository**.

## Step 2 — Upload the single ZIP

1. On the empty repository page, tap **uploading an existing file**. If that link is not shown, use **Add file → Upload files**.
2. Select `Clarity-PDF-Android-v1.0-Source.zip` directly from Downloads.
3. Do not extract it.
4. Enter `Upload Clarity PDF source ZIP` in the commit box.
5. Tap **Commit changes**.

The repository should contain one uploaded item: `Clarity-PDF-Android-v1.0-Source.zip`.

## Step 3 — Add the automatic builder once

1. Open the repository's **Actions** tab.
2. Tap **set up a workflow yourself**.
3. Change the filename shown above the editor to `build-from-zip.yml`.
4. Delete all sample text from the editor.
5. Open `PASTE-IN-GITHUB-ACTIONS.yml` from ChatGPT, select all its text, and copy it.
6. Paste that complete text into the GitHub editor.
7. Tap **Commit changes**, then confirm **Commit changes** again.

This workflow uses Java 21 and automatically extracts the uploaded ZIP before compiling.

## Step 4 — Download the APK

1. Return to **Actions**.
2. Open **Build Clarity PDF APK from ZIP**.
3. The first build normally starts automatically after the workflow is committed. If it does not, tap **Run workflow**.
4. Wait until a green tick appears.
5. Open the completed run and scroll to **Artifacts**.
6. Download **Clarity-PDF-Android-APK**.
7. Extract the small artifact ZIP and install `Clarity-PDF-v1.0.apk`.

If Android blocks installation, allow **Install unknown apps** for Chrome or your file manager, then tap the APK again.

## Future updates

Upload a new file with the same exact name, `Clarity-PDF-Android-v1.0-Source.zip`, and replace the old ZIP in the repository. The workflow will build the updated APK automatically.
