package com.moneyclaritytech.claritypdf;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.OpenableColumns;

import com.getcapacitor.BridgeActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(IncomingPdfPlugin.class);
        super.onCreate(savedInstanceState);
        acceptPdfIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        acceptPdfIntent(intent);
    }

    private void acceptPdfIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) uri = intent.getData();
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            } else {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            }
        }
        if (uri == null) return;
        final Uri inputUri = uri;
        new Thread(() -> copyIncomingPdf(inputUri)).start();
    }

    private void copyIncomingPdf(Uri uri) {
        try {
            String name = resolveName(uri);
            if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
            File directory = new File(getCacheDir(), "incoming");
            if (!directory.exists()) directory.mkdirs();
            File destination = new File(directory, System.currentTimeMillis() + "-" + name.replaceAll("[^a-zA-Z0-9._ -]", "_"));
            try (InputStream input = getContentResolver().openInputStream(uri);
                 FileOutputStream output = new FileOutputStream(destination)) {
                if (input == null) return;
                byte[] buffer = new byte[64 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
            IncomingPdfPlugin.offer(destination.getAbsolutePath(), name);
            runOnUiThread(() -> {
                if (bridge != null && bridge.getWebView() != null) {
                    bridge.getWebView().evaluateJavascript("window.dispatchEvent(new Event('clarity-incoming-ready'))", null);
                }
            });
        } catch (Exception ignored) {
            // The app remains usable through its normal file picker.
        }
    }

    private String resolveName(Uri uri) {
        String name = "Shared-Document.pdf";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return name == null || name.isBlank() ? "Shared-Document.pdf" : name;
    }
}
