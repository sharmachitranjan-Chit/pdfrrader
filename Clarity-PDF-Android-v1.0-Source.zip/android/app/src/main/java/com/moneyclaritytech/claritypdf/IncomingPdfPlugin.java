package com.moneyclaritytech.claritypdf;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "IncomingPdf")
public class IncomingPdfPlugin extends Plugin {
    private static String pendingPath;
    private static String pendingName;

    public static synchronized void offer(String path, String name) {
        pendingPath = path;
        pendingName = name;
    }

    @PluginMethod
    public synchronized void getIncoming(PluginCall call) {
        JSObject result = new JSObject();
        if (pendingPath != null) {
            result.put("path", pendingPath);
            result.put("name", pendingName);
            pendingPath = null;
            pendingName = null;
        }
        call.resolve(result);
    }
}
