import * as pdfjsLib from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {
  PDFCheckBox,
  PDFDocument,
  PDFDropdown,
  PDFOptionList,
  PDFRadioGroup,
  PDFTextField,
  StandardFonts,
  degrees,
  rgb,
} from 'pdf-lib';
import type { Annotation, PageSpec } from './types';

pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;

export type FormFieldInfo = {
  name: string;
  type: 'text' | 'checkbox' | 'dropdown' | 'radio' | 'options' | 'unsupported';
  value: string | boolean;
  options: string[];
};

const hexToRgb = (hex: string) => {
  const clean = hex.replace('#', '');
  const n = Number.parseInt(clean.length === 3 ? clean.split('').map((x) => x + x).join('') : clean, 16);
  return rgb(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255);
};

const cloneBytes = (bytes: Uint8Array) => new Uint8Array(bytes);

export class PdfEngine {
  bytes = new Uint8Array();
  document: pdfjsLib.PDFDocumentProxy | null = null;
  private loadingTask: pdfjsLib.PDFDocumentLoadingTask | null = null;
  name = 'Document.pdf';

  get pageCount() {
    return this.document?.numPages ?? 0;
  }

  async load(bytes: Uint8Array, name = 'Document.pdf'): Promise<void> {
    await this.close();
    this.bytes = cloneBytes(bytes);
    this.name = name;
    const task = pdfjsLib.getDocument({ data: cloneBytes(bytes) });
    this.loadingTask = task;
    task.onPassword = (setPassword: (password: string) => void, reason: number) => {
      const message = reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD
        ? 'Incorrect password. Try again:'
        : 'This PDF is password protected. Enter the password:';
      const password = window.prompt(message);
      if (password !== null) setPassword(password);
    };
    this.document = await task.promise;
  }

  async close(): Promise<void> {
    if (this.loadingTask) {
      try { await this.loadingTask.destroy(); } catch { /* already closed */ }
    }
    this.loadingTask = null;
    this.document = null;
  }

  async renderPage(pageNumber: number, canvas: HTMLCanvasElement, cssWidth: number): Promise<{ width: number; height: number }> {
    if (!this.document) throw new Error('No PDF is open');
    const page = await this.document.getPage(pageNumber);
    const unit = page.getViewport({ scale: 1 });
    const scale = Math.max(0.2, cssWidth / unit.width);
    const viewport = page.getViewport({ scale });
    const outputScale = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(viewport.width * outputScale);
    canvas.height = Math.floor(viewport.height * outputScale);
    canvas.style.width = `${viewport.width}px`;
    canvas.style.height = `${viewport.height}px`;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('Canvas is unavailable');
    context.setTransform(outputScale, 0, 0, outputScale, 0, 0);
    await page.render({ canvasContext: context, viewport, canvas }).promise;
    return { width: viewport.width, height: viewport.height };
  }

  async pageAspect(pageNumber: number): Promise<number> {
    if (!this.document) return 1.414;
    const page = await this.document.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 1 });
    return viewport.height / viewport.width;
  }

  async search(query: string): Promise<Array<{ page: number; count: number; preview: string }>> {
    if (!this.document || !query.trim()) return [];
    const needle = query.trim().toLocaleLowerCase();
    const hits: Array<{ page: number; count: number; preview: string }> = [];
    for (let pageNumber = 1; pageNumber <= this.document.numPages; pageNumber += 1) {
      const page = await this.document.getPage(pageNumber);
      const content = await page.getTextContent();
      const text = content.items.map((item) => ('str' in item ? item.str : '')).join(' ').replace(/\s+/g, ' ').trim();
      const lower = text.toLocaleLowerCase();
      let count = 0;
      let cursor = 0;
      while ((cursor = lower.indexOf(needle, cursor)) !== -1) {
        count += 1;
        cursor += needle.length;
      }
      if (count) {
        const at = lower.indexOf(needle);
        hits.push({ page: pageNumber, count, preview: text.slice(Math.max(0, at - 38), Math.min(text.length, at + needle.length + 54)) });
      }
    }
    return hits;
  }

  private async pointToPdf(pageIndex: number, x: number, y: number): Promise<[number, number]> {
    if (!this.document) throw new Error('No PDF is open');
    const page = await this.document.getPage(pageIndex + 1);
    const viewport = page.getViewport({ scale: 1 });
    return viewport.convertToPdfPoint(x * viewport.width, y * viewport.height) as [number, number];
  }

  async exportAnnotations(annotations: Annotation[]): Promise<Uint8Array> {
    if (!annotations.length) return cloneBytes(this.bytes);
    let pdf: PDFDocument;
    try {
      pdf = await PDFDocument.load(cloneBytes(this.bytes));
    } catch {
      throw new Error('This protected or unusually encoded PDF can be read, but this version cannot safely rewrite it. Try saving an unlocked copy first.');
    }
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const pages = pdf.getPages();

    for (const annotation of annotations) {
      const page = pages[annotation.page];
      if (!page) continue;
      const color = hexToRgb(annotation.color);
      if (annotation.points?.length) {
        for (let i = 1; i < annotation.points.length; i += 1) {
          const [x1, y1] = await this.pointToPdf(annotation.page, annotation.points[i - 1].x, annotation.points[i - 1].y);
          const [x2, y2] = await this.pointToPdf(annotation.page, annotation.points[i].x, annotation.points[i].y);
          page.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: annotation.width, color, opacity: annotation.opacity, lineCap: 1 });
        }
      }
      if (annotation.rect) {
        const a = await this.pointToPdf(annotation.page, annotation.rect.x, annotation.rect.y);
        const b = await this.pointToPdf(annotation.page, annotation.rect.x + annotation.rect.w, annotation.rect.y + annotation.rect.h);
        const x = Math.min(a[0], b[0]);
        const y = Math.min(a[1], b[1]);
        const width = Math.abs(b[0] - a[0]);
        const height = Math.abs(b[1] - a[1]);
        if (annotation.kind === 'highlight') {
          page.drawRectangle({ x, y, width, height, color, opacity: 0.28, blendMode: 'Multiply' as never });
        } else if (annotation.kind === 'redact') {
          page.drawRectangle({ x, y, width, height, color: rgb(0.04, 0.04, 0.05), opacity: 1 });
        } else if (annotation.kind === 'replace') {
          page.drawRectangle({ x, y, width, height, color: rgb(1, 1, 1), opacity: 1 });
          if (annotation.text) {
            const size = Math.max(7, Math.min(height * 0.72, annotation.fontSize ? annotation.fontSize * page.getWidth() : 12));
            page.drawText(annotation.text, { x: x + 3, y: y + Math.max(2, height - size - 2), size, font, color: hexToRgb(annotation.color), maxWidth: Math.max(5, width - 6) });
          }
        } else if (annotation.kind === 'image' && annotation.imageData) {
          const imageBytes = await (await fetch(annotation.imageData)).arrayBuffer();
          const embedded = annotation.imageData.startsWith('data:image/png')
            ? await pdf.embedPng(imageBytes)
            : await pdf.embedJpg(imageBytes);
          page.drawImage(embedded, { x, y, width, height, opacity: annotation.opacity });
        }
      }
      if (annotation.kind === 'text' && annotation.text && annotation.rect) {
        const [x, y] = await this.pointToPdf(annotation.page, annotation.rect.x, annotation.rect.y);
        const size = Math.max(7, annotation.fontSize ? annotation.fontSize * page.getWidth() : 13);
        page.drawText(annotation.text, { x, y: y - size, size, font, color, maxWidth: page.getWidth() * Math.max(0.1, annotation.rect.w || 0.7), lineHeight: size * 1.2 });
      }
    }
    return await pdf.save({ useObjectStreams: true });
  }

  async rebuildPages(sourceBytes: Uint8Array, specs: PageSpec[]): Promise<Uint8Array> {
    if (!specs.length) throw new Error('A PDF needs at least one page');
    const source = await PDFDocument.load(cloneBytes(sourceBytes));
    const out = await PDFDocument.create();
    for (const spec of specs) {
      const [copied] = await out.copyPages(source, [spec.source]);
      const original = copied.getRotation().angle;
      copied.setRotation(degrees((original + spec.rotation + 360) % 360));
      out.addPage(copied);
    }
    return await out.save({ useObjectStreams: true });
  }

  async extractPages(sourceBytes: Uint8Array, specs: PageSpec[]): Promise<Uint8Array> {
    return this.rebuildPages(sourceBytes, specs.filter((page) => page.selected));
  }

  static async merge(files: File[]): Promise<Uint8Array> {
    if (files.length < 2) throw new Error('Choose at least two PDF files');
    const output = await PDFDocument.create();
    for (const file of files) {
      const source = await PDFDocument.load(await file.arrayBuffer());
      const pages = await output.copyPages(source, source.getPageIndices());
      pages.forEach((page) => output.addPage(page));
    }
    return await output.save({ useObjectStreams: true });
  }

  static async imagesToPdf(files: File[]): Promise<Uint8Array> {
    if (!files.length) throw new Error('Choose one or more JPG or PNG images');
    const pdf = await PDFDocument.create();
    for (const file of files) {
      const bytes = await file.arrayBuffer();
      const image = file.type === 'image/png' ? await pdf.embedPng(bytes) : await pdf.embedJpg(bytes);
      const a4 = { width: 595.28, height: 841.89 };
      const page = pdf.addPage([a4.width, a4.height]);
      const margin = 28;
      const scale = Math.min((a4.width - margin * 2) / image.width, (a4.height - margin * 2) / image.height);
      const width = image.width * scale;
      const height = image.height * scale;
      page.drawImage(image, { x: (a4.width - width) / 2, y: (a4.height - height) / 2, width, height });
    }
    return await pdf.save({ useObjectStreams: true });
  }

  static async blank(): Promise<Uint8Array> {
    const pdf = await PDFDocument.create();
    pdf.addPage([595.28, 841.89]);
    return await pdf.save();
  }

  static async sample(): Promise<Uint8Array> {
    const pdf = await PDFDocument.create();
    const regular = await pdf.embedFont(StandardFonts.Helvetica);
    const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const page = pdf.addPage([595.28, 841.89]);
    page.drawRectangle({ x: 0, y: 730, width: 595.28, height: 112, color: rgb(0.31, 0.27, 0.9) });
    page.drawText('Clarity PDF', { x: 44, y: 782, size: 30, font: bold, color: rgb(1, 1, 1) });
    page.drawText('Private. Practical. Ready to edit.', { x: 44, y: 754, size: 13, font: regular, color: rgb(0.9, 0.89, 1) });
    page.drawText('Try the editor', { x: 44, y: 670, size: 24, font: bold, color: rgb(0.12, 0.13, 0.19) });
    page.drawText('Use the bottom toolbar to draw, highlight, add text, sign, insert an image, or redact.', { x: 44, y: 635, size: 12, font: regular, color: rgb(0.31, 0.33, 0.4), maxWidth: 500, lineHeight: 18 });
    ['Pinch to zoom and scroll naturally', 'Search text across every page', 'Organize, rotate, duplicate and extract pages', 'Save a new copy or share it securely'].forEach((line, index) => {
      const y = 570 - index * 55;
      page.drawCircle({ x: 56, y: y + 5, size: 10, color: rgb(0.88, 0.87, 1) });
      page.drawLine({ start: { x: 51, y: y + 5 }, end: { x: 55, y: y + 1 }, thickness: 1.8, color: rgb(0.31, 0.27, 0.9) });
      page.drawLine({ start: { x: 55, y: y + 1 }, end: { x: 62, y: y + 10 }, thickness: 1.8, color: rgb(0.31, 0.27, 0.9) });
      page.drawText(line, { x: 82, y, size: 14, font: regular, color: rgb(0.16, 0.17, 0.23) });
    });
    page.drawRectangle({ x: 44, y: 235, width: 507, height: 90, color: rgb(0.96, 0.96, 0.99), borderColor: rgb(0.87, 0.87, 0.94), borderWidth: 1 });
    page.drawText('Offline-first privacy', { x: 64, y: 286, size: 15, font: bold, color: rgb(0.12, 0.13, 0.19) });
    page.drawText('Your document is processed on your device. No account, ads, or upload server.', { x: 64, y: 258, size: 11, font: regular, color: rgb(0.35, 0.36, 0.43), maxWidth: 450 });
    return await pdf.save();
  }

  async readFormFields(): Promise<FormFieldInfo[]> {
    const pdf = await PDFDocument.load(cloneBytes(this.bytes));
    const form = pdf.getForm();
    return form.getFields().map((field): FormFieldInfo => {
      const name = field.getName();
      if (field instanceof PDFTextField) return { name, type: 'text', value: field.getText() ?? '', options: [] };
      if (field instanceof PDFCheckBox) return { name, type: 'checkbox', value: field.isChecked(), options: [] };
      if (field instanceof PDFDropdown) return { name, type: 'dropdown', value: field.getSelected()[0] ?? '', options: field.getOptions() };
      if (field instanceof PDFRadioGroup) return { name, type: 'radio', value: field.getSelected() ?? '', options: field.getOptions() };
      if (field instanceof PDFOptionList) return { name, type: 'options', value: field.getSelected().join(', '), options: field.getOptions() };
      return { name, type: 'unsupported', value: '', options: [] };
    });
  }

  async applyForm(values: Record<string, string | boolean>): Promise<Uint8Array> {
    const pdf = await PDFDocument.load(cloneBytes(this.bytes));
    const form = pdf.getForm();
    for (const field of form.getFields()) {
      if (!(field.getName() in values)) continue;
      const value = values[field.getName()];
      if (field instanceof PDFTextField) field.setText(String(value));
      else if (field instanceof PDFCheckBox) value ? field.check() : field.uncheck();
      else if (field instanceof PDFDropdown) field.select(String(value));
      else if (field instanceof PDFRadioGroup) field.select(String(value));
      else if (field instanceof PDFOptionList) field.select(String(value).split(',').map((x) => x.trim()).filter(Boolean));
    }
    form.updateFieldAppearances(await pdf.embedFont(StandardFonts.Helvetica));
    return await pdf.save({ useObjectStreams: true });
  }
}

export function bytesFromFile(file: File): Promise<Uint8Array> {
  return file.arrayBuffer().then((buffer) => new Uint8Array(buffer));
}

export function bytesToDataUrl(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return `data:application/pdf;base64,${btoa(binary)}`;
}
