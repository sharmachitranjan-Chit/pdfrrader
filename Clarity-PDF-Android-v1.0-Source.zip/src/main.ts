import './style.css';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { PdfEngine, bytesFromFile, bytesToDataUrl, type FormFieldInfo } from './pdf-engine';
import { icon } from './icons';
import { DEFAULT_SETTINGS, type Annotation, type AppSettings, type PageSpec, type RecentFile, type Tool } from './types';

const app = document.querySelector<HTMLDivElement>('#app')!;
const pdfPicker = document.querySelector<HTMLInputElement>('#pdf-picker')!;
const multiPdfPicker = document.querySelector<HTMLInputElement>('#multi-pdf-picker')!;
const imagePicker = document.querySelector<HTMLInputElement>('#image-picker')!;
const multiImagePicker = document.querySelector<HTMLInputElement>('#multi-image-picker')!;
const engine = new PdfEngine();
const IncomingPdf = registerPlugin<{ getIncoming(): Promise<{ path?: string; name?: string }> }>('IncomingPdf');

const store = {
  get<T>(key: string, fallback: T): T {
    try { return JSON.parse(localStorage.getItem(key) || '') as T; } catch { return fallback; }
  },
  set(key: string, value: unknown) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* device storage full */ }
  },
};

let settings = { ...DEFAULT_SETTINGS, ...store.get<Partial<AppSettings>>('clarity.settings', {}) };
let recents = store.get<RecentFile[]>('clarity.recents', []);
let screen: 'home' | 'tools' | 'settings' | 'document' = 'home';
let annotations: Annotation[] = [];
let undoStack: Annotation[][] = [];
let redoStack: Annotation[][] = [];
let activeTool: Tool = 'read';
let activeColor = settings.defaultInk;
let activeWidth = 2.5;
let currentFingerprint = '';
let currentSourceFile: File | null = null;
let pendingImage: string | null = null;
let isBusy = false;
let currentPage = 1;

const safe = (value: string) => value.replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]!));
const id = () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
const formatBytes = (bytes: number) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(bytes > 10 * 1024 * 1024 ? 0 : 1)} MB`;
const formatDate = (time: number) => new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }).format(time);

function applyTheme() {
  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.dataset.gap = settings.pageGap;
}

function toast(message: string, tone: 'default' | 'success' | 'error' = 'default') {
  document.querySelector('.toast')?.remove();
  const el = document.createElement('div');
  el.className = `toast ${tone}`;
  el.innerHTML = `${icon(tone === 'success' ? 'check' : tone === 'error' ? 'info' : 'info', 19)}<span>${safe(message)}</span>`;
  document.body.append(el);
  window.setTimeout(() => el.classList.add('show'), 20);
  window.setTimeout(() => { el.classList.remove('show'); window.setTimeout(() => el.remove(), 220); }, 3200);
}

function setBusy(value: boolean, label = 'Working…') {
  isBusy = value;
  document.querySelector('.busy-layer')?.remove();
  if (!value) return;
  const busy = document.createElement('div');
  busy.className = 'busy-layer';
  busy.innerHTML = `<div class="busy-card"><div class="spinner"></div><strong>${safe(label)}</strong><span>Keep the app open</span></div>`;
  document.body.append(busy);
}

function bottomNav(active: 'home' | 'tools' | 'settings') {
  return `<nav class="bottom-nav" aria-label="Main navigation">
    <button data-nav="home" class="${active === 'home' ? 'active' : ''}">${icon('home')}<span>Library</span></button>
    <button data-nav="tools" class="${active === 'tools' ? 'active' : ''}">${icon('tools')}<span>Tools</span></button>
    <button data-nav="settings" class="${active === 'settings' ? 'active' : ''}">${icon('settings')}<span>Settings</span></button>
  </nav>`;
}

function renderHome() {
  screen = 'home';
  const recentCards = recents.length
    ? recents.slice(0, 8).map((file) => `<button class="recent-card" data-recent="${safe(file.fingerprint)}">
        <span class="pdf-badge">PDF</span>
        <span class="recent-info"><strong>${safe(file.name)}</strong><small>${file.pages} pages · ${formatBytes(file.size)} · ${formatDate(file.openedAt)}</small></span>
        ${icon('chevron', 19)}
      </button>`).join('')
    : `<div class="empty-recents">${icon('file', 34)}<strong>No recent documents</strong><span>PDFs you open will appear here. Files remain on your device.</span></div>`;
  app.innerHTML = `<main class="app-shell home-screen">
    <header class="home-header">
      <div class="brand"><img src="./logo.svg" alt=""><div><strong>Clarity PDF</strong><span>Private PDF workspace</span></div></div>
      <span class="privacy-pill">${icon('shield', 16)} Offline</span>
    </header>
    <section class="hero-card">
      <span class="eyebrow">READ · EDIT · SIGN</span>
      <h1>Everything your PDF needs.</h1>
      <p>Open documents, make precise changes, organize pages and save a clean copy—without ads or an account.</p>
      <div class="hero-actions">
        <button class="primary-btn" data-action="open">${icon('folder')} Open PDF</button>
        <button class="soft-btn" data-action="sample">Try sample</button>
      </div>
      <div class="privacy-note">${icon('lock', 17)} <span>Documents are processed on this device</span></div>
    </section>
    <section class="quick-section">
      <div class="section-title"><div><span>Quick actions</span><h2>Start in one tap</h2></div></div>
      <div class="quick-grid">
        <button data-tool="merge"><span class="quick-icon violet">${icon('merge')}</span><strong>Merge PDFs</strong><small>Combine files</small></button>
        <button data-tool="images"><span class="quick-icon coral">${icon('image')}</span><strong>Photos to PDF</strong><small>JPG or PNG</small></button>
        <button data-tool="blank"><span class="quick-icon blue">${icon('blank')}</span><strong>Blank PDF</strong><small>Start fresh</small></button>
      </div>
    </section>
    <section class="recent-section">
      <div class="section-title"><div><span>Your files</span><h2>Recent</h2></div>${recents.length ? '<button data-action="clear-recents">Clear</button>' : ''}</div>
      <div class="recent-list">${recentCards}</div>
    </section>
    ${bottomNav('home')}
  </main>`;
}

function renderTools() {
  screen = 'tools';
  app.innerHTML = `<main class="app-shell simple-screen">
    <header class="page-header"><div><span>PDF toolbox</span><h1>Useful tools</h1></div><span class="privacy-pill">${icon('shield', 16)} Local</span></header>
    <section class="tool-list">
      <button class="tool-card" data-tool="merge"><span class="tool-card-icon violet">${icon('merge', 25)}</span><span><strong>Merge PDFs</strong><small>Combine two or more files in your chosen order</small></span>${icon('chevron')}</button>
      <button class="tool-card" data-tool="images"><span class="tool-card-icon coral">${icon('image', 25)}</span><span><strong>Images to PDF</strong><small>Put JPG and PNG images onto clean A4 pages</small></span>${icon('chevron')}</button>
      <button class="tool-card" data-tool="blank"><span class="tool-card-icon blue">${icon('blank', 25)}</span><span><strong>Create blank PDF</strong><small>Make an A4 page for writing, signing or notes</small></span>${icon('chevron')}</button>
      <button class="tool-card" data-action="open"><span class="tool-card-icon green">${icon('form', 25)}</span><span><strong>Fill & sign</strong><small>Open a form or place text and a handwritten signature</small></span>${icon('chevron')}</button>
      <button class="tool-card" data-action="open"><span class="tool-card-icon amber">${icon('pages', 25)}</span><span><strong>Organize pages</strong><small>Reorder, rotate, duplicate, delete or extract pages</small></span>${icon('chevron')}</button>
    </section>
    <div class="info-card">${icon('info', 20)}<p><strong>Works without uploading.</strong> Large files depend on the free memory available on your phone.</p></div>
    ${bottomNav('tools')}
  </main>`;
}

function renderSettings() {
  screen = 'settings';
  const themeLabel = settings.theme === 'system' ? 'Use phone setting' : settings.theme === 'dark' ? 'Dark' : 'Light';
  app.innerHTML = `<main class="app-shell simple-screen">
    <header class="page-header"><div><span>Make it yours</span><h1>Settings</h1></div>${icon('settings', 27)}</header>
    <section class="settings-group">
      <h2>Appearance</h2>
      <button class="setting-row" data-setting="theme"><span class="setting-icon">${icon('moon')}</span><span><strong>Theme</strong><small>${themeLabel}</small></span>${icon('chevron')}</button>
      <button class="setting-row" data-setting="gap"><span class="setting-icon">${icon('pages')}</span><span><strong>Page spacing</strong><small>${settings.pageGap === 'compact' ? 'Compact' : 'Comfortable'}</small></span>${icon('chevron')}</button>
    </section>
    <section class="settings-group">
      <h2>Editor</h2>
      <label class="setting-row"><span class="setting-icon">${icon('save')}</span><span><strong>Remember unfinished edits</strong><small>Restore annotations when the same file is reopened</small></span><input type="checkbox" data-toggle="drafts" ${settings.rememberDrafts ? 'checked' : ''}><i class="switch"></i></label>
      <div class="setting-row color-setting"><span class="setting-icon">${icon('pen')}</span><span><strong>Default ink colour</strong><small>Used for pen and text</small></span><input type="color" data-color="ink" value="${settings.defaultInk}"></div>
    </section>
    <section class="settings-group">
      <h2>Privacy & about</h2>
      <div class="setting-row static"><span class="setting-icon">${icon('shield')}</span><span><strong>Offline by default</strong><small>No account, analytics, ads or PDF upload server</small></span>${icon('check')}</div>
      <div class="setting-row static"><span class="setting-icon">${icon('info')}</span><span><strong>Clarity PDF 1.0</strong><small>Open-source components · Built for Android</small></span></div>
    </section>
    ${bottomNav('settings')}
  </main>`;
}

async function openFile(file: File) {
  if (!file || (!file.type.includes('pdf') && !file.name.toLowerCase().endsWith('.pdf'))) {
    toast('Please choose a PDF file', 'error'); return;
  }
  if (file.size > 120 * 1024 * 1024 && !window.confirm('This PDF is larger than 120 MB. It may use significant memory. Continue?')) return;
  setBusy(true, 'Opening PDF…');
  try {
    const bytes = await bytesFromFile(file);
    await engine.load(bytes, file.name);
    currentSourceFile = file;
    currentFingerprint = `${file.name}-${file.size}-${file.lastModified}`;
    annotations = settings.rememberDrafts ? store.get<Annotation[]>(`clarity.draft.${currentFingerprint}`, []) : [];
    undoStack = []; redoStack = []; activeTool = 'read'; currentPage = 1;
    updateRecent(file.name, file.size, engine.pageCount, currentFingerprint);
    renderDocument();
  } catch (error) {
    toast(error instanceof Error ? error.message : 'This PDF could not be opened', 'error');
  } finally { setBusy(false); pdfPicker.value = ''; }
}

async function openGenerated(bytes: Uint8Array, name: string) {
  const file = new File([bytes as BlobPart], name, { type: 'application/pdf', lastModified: Date.now() });
  await openFile(file);
}

function updateRecent(name: string, size: number, pages: number, fingerprint: string) {
  recents = [{ name, size, pages, fingerprint, openedAt: Date.now() }, ...recents.filter((item) => item.fingerprint !== fingerprint)].slice(0, 12);
  store.set('clarity.recents', recents);
}

function saveDraft() {
  if (!settings.rememberDrafts || !currentFingerprint) return;
  store.set(`clarity.draft.${currentFingerprint}`, annotations);
}

function checkpoint() {
  undoStack.push(structuredClone(annotations));
  if (undoStack.length > 30) undoStack.shift();
  redoStack = [];
}

function undo() {
  const previous = undoStack.pop();
  if (!previous) return;
  redoStack.push(structuredClone(annotations)); annotations = previous; saveDraft(); redrawAllOverlays(); updateEditorActions();
}

function redo() {
  const next = redoStack.pop();
  if (!next) return;
  undoStack.push(structuredClone(annotations)); annotations = next; saveDraft(); redrawAllOverlays(); updateEditorActions();
}

function renderDocument() {
  screen = 'document';
  app.innerHTML = `<main class="document-screen">
    <header class="doc-header">
      <button class="icon-btn" data-action="back" aria-label="Back">${icon('back')}</button>
      <div class="doc-title"><strong>${safe(engine.name)}</strong><span>${engine.pageCount} page${engine.pageCount === 1 ? '' : 's'} · ${formatBytes(engine.bytes.length)}</span></div>
      <button class="icon-btn" data-action="search" aria-label="Search">${icon('search')}</button>
      <button class="icon-btn" data-action="more" aria-label="More options">${icon('more')}</button>
    </header>
    <div class="doc-status"><span id="page-indicator">1 / ${engine.pageCount}</span><span>${annotations.length ? `${annotations.length} unsaved edit${annotations.length === 1 ? '' : 's'}` : 'Viewing original'}</span></div>
    <section class="pdf-scroll" id="pdf-scroll" aria-label="PDF pages">
      ${Array.from({ length: engine.pageCount }, (_, index) => `<article class="pdf-page-shell" id="page-${index + 1}" data-page="${index}"><div class="page-placeholder"><div class="page-loader"></div></div><span class="page-number">${index + 1}</span></article>`).join('')}
    </section>
    <div class="editor-toolbar">
      <div class="mode-row">
        <button data-mode="read" class="${activeTool === 'read' ? 'active' : ''}">${icon('eye')}<span>Read</span></button>
        <button data-mode="annotate" class="${activeTool !== 'read' ? 'active' : ''}">${icon('pen')}<span>Edit</span></button>
        <button data-action="pages">${icon('pages')}<span>Pages</span></button>
        <button data-action="forms">${icon('form')}<span>Fill</span></button>
        <button data-action="save" class="save-mode">${icon('save')}<span>Save</span></button>
      </div>
      <div class="annotation-row ${activeTool === 'read' ? '' : 'open'}">
        ${toolButton('pen', 'Pen')}${toolButton('highlight', 'Highlight')}${toolButton('text', 'Text')}${toolButton('replace', 'Replace')}${toolButton('redact', 'Redact')}${toolButton('signature', 'Sign')}${toolButton('image', 'Image')}${toolButton('eraser', 'Erase')}
      </div>
      <div class="edit-options ${activeTool === 'read' ? '' : 'open'}">
        <div class="color-swatches">
          ${['#E5484D', '#F59E0B', '#22A06B', '#2563EB', '#4F46E5', '#111318'].map((color) => `<button aria-label="Colour ${color}" data-ink="${color}" style="--swatch:${color}" class="${activeColor === color ? 'active' : ''}"></button>`).join('')}
        </div>
        <input aria-label="Stroke width" type="range" min="1" max="8" step="0.5" value="${activeWidth}" data-width>
        <button class="mini-btn" data-action="undo" ${undoStack.length ? '' : 'disabled'}>${icon('undo', 18)}</button>
        <button class="mini-btn" data-action="redo" ${redoStack.length ? '' : 'disabled'}>${icon('redo', 18)}</button>
      </div>
    </div>
  </main>`;
  initializePageRendering();
}

function toolButton(tool: Tool, label: string) {
  return `<button data-edit-tool="${tool}" class="${activeTool === tool ? 'active' : ''}">${icon(tool)}<span>${label}</span></button>`;
}

function initializePageRendering() {
  const scroll = document.querySelector<HTMLElement>('#pdf-scroll')!;
  const shells = Array.from(document.querySelectorAll<HTMLElement>('.pdf-page-shell'));
  let resizeTimer = 0;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) renderPageShell(entry.target as HTMLElement);
    });
  }, { root: scroll, rootMargin: '700px 0px', threshold: 0.01 });
  shells.forEach((shell) => observer.observe(shell));
  const pageObserver = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (visible) {
      currentPage = Number((visible.target as HTMLElement).dataset.page) + 1;
      const indicator = document.querySelector('#page-indicator');
      if (indicator) indicator.textContent = `${currentPage} / ${engine.pageCount}`;
    }
  }, { root: scroll, threshold: [0.15, 0.4, 0.7] });
  shells.forEach((shell) => pageObserver.observe(shell));
  window.addEventListener('resize', () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(() => shells.filter((shell) => shell.dataset.rendered === 'true').forEach((shell) => { shell.dataset.rendered = ''; renderPageShell(shell); }), 180);
  }, { once: true });
}

async function renderPageShell(shell: HTMLElement) {
  if (shell.dataset.rendered === 'loading' || shell.dataset.rendered === 'true') return;
  shell.dataset.rendered = 'loading';
  const pageIndex = Number(shell.dataset.page);
  try {
    const maxWidth = Math.min(920, Math.max(280, (document.querySelector('#pdf-scroll')?.clientWidth ?? window.innerWidth) - 24));
    const canvas = document.createElement('canvas');
    canvas.className = 'pdf-canvas';
    const overlay = document.createElement('canvas');
    overlay.className = 'page-overlay';
    const size = await engine.renderPage(pageIndex + 1, canvas, maxWidth);
    const dpr = Math.min(devicePixelRatio || 1, 2);
    overlay.width = Math.floor(size.width * dpr); overlay.height = Math.floor(size.height * dpr);
    overlay.style.width = `${size.width}px`; overlay.style.height = `${size.height}px`;
    overlay.dataset.page = String(pageIndex);
    shell.querySelector('.page-placeholder')?.replaceWith(canvas);
    shell.append(overlay);
    attachOverlayEvents(overlay);
    drawOverlay(overlay);
    shell.dataset.rendered = 'true';
  } catch {
    shell.innerHTML = `<div class="page-error">${icon('info')}<span>Page ${pageIndex + 1} could not be rendered</span></div>`;
    shell.dataset.rendered = 'error';
  }
}

function drawOverlay(canvas: HTMLCanvasElement, draft?: Annotation) {
  const ctx = canvas.getContext('2d')!;
  const cssWidth = canvas.clientWidth || Number.parseFloat(canvas.style.width);
  const cssHeight = canvas.clientHeight || Number.parseFloat(canvas.style.height);
  const scale = canvas.width / cssWidth;
  ctx.setTransform(scale, 0, 0, scale, 0, 0); ctx.clearRect(0, 0, cssWidth, cssHeight);
  const page = Number(canvas.dataset.page);
  [...annotations.filter((item) => item.page === page), ...(draft ? [draft] : [])].forEach((item) => drawAnnotation(ctx, item, cssWidth, cssHeight));
}

function drawAnnotation(ctx: CanvasRenderingContext2D, item: Annotation, width: number, height: number) {
  ctx.save(); ctx.globalAlpha = item.opacity; ctx.strokeStyle = item.color; ctx.fillStyle = item.color; ctx.lineWidth = item.width; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (item.points?.length) {
    ctx.beginPath(); ctx.moveTo(item.points[0].x * width, item.points[0].y * height);
    item.points.slice(1).forEach((point) => ctx.lineTo(point.x * width, point.y * height)); ctx.stroke();
  }
  if (item.rect) {
    const x = item.rect.x * width, y = item.rect.y * height, w = item.rect.w * width, h = item.rect.h * height;
    if (item.kind === 'highlight') { ctx.globalAlpha = 0.28; ctx.globalCompositeOperation = 'multiply'; ctx.fillRect(x, y, w, h); }
    if (item.kind === 'redact') { ctx.globalAlpha = 1; ctx.fillStyle = '#111318'; ctx.fillRect(x, y, w, h); }
    if (item.kind === 'replace') { ctx.globalAlpha = 1; ctx.fillStyle = '#fff'; ctx.fillRect(x, y, w, h); ctx.strokeStyle = '#d7d9e3'; ctx.strokeRect(x, y, w, h); if (item.text) { ctx.fillStyle = item.color; ctx.font = `${Math.max(11, (item.fontSize ?? .025) * width)}px sans-serif`; ctx.fillText(item.text, x + 4, y + Math.max(14, (item.fontSize ?? .025) * width + 2), w - 8); } }
    if (item.kind === 'image' && item.imageData) { const img = new Image(); img.onload = () => { ctx.drawImage(img, x, y, w, h); }; img.src = item.imageData; ctx.strokeStyle = '#4F46E5'; ctx.setLineDash([6, 4]); ctx.strokeRect(x, y, w, h); }
    if (item.kind === 'text' && item.text) { ctx.globalAlpha = 1; ctx.font = `600 ${Math.max(11, (item.fontSize ?? .025) * width)}px sans-serif`; ctx.fillStyle = item.color; wrapCanvasText(ctx, item.text, x, y + Math.max(12, (item.fontSize ?? .025) * width), Math.max(70, w), Math.max(14, (item.fontSize ?? .025) * width * 1.2)); }
  }
  ctx.restore();
}

function wrapCanvasText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
  let line = '';
  text.split(/\s+/).forEach((word) => {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) { ctx.fillText(line, x, y); line = word; y += lineHeight; } else line = test;
  });
  if (line) ctx.fillText(line, x, y);
}

function attachOverlayEvents(canvas: HTMLCanvasElement) {
  let draft: Annotation | null = null;
  const point = (event: PointerEvent) => {
    const rect = canvas.getBoundingClientRect();
    return { x: Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width)), y: Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height)) };
  };
  canvas.addEventListener('pointerdown', (event) => {
    if (activeTool === 'read') return;
    event.preventDefault(); canvas.setPointerCapture(event.pointerId);
    const p = point(event); const page = Number(canvas.dataset.page);
    if (activeTool === 'text') { showTextDialog(page, p); return; }
    if (activeTool === 'image') {
      if (!pendingImage) { imagePicker.click(); toast('Choose an image, then tap where you want it'); return; }
      checkpoint(); annotations.push({ id: id(), page, kind: 'image', color: '#4F46E5', opacity: 1, width: 1, rect: { x: p.x, y: p.y, w: Math.min(.36, 1 - p.x), h: Math.min(.24, 1 - p.y) }, imageData: pendingImage }); pendingImage = null; finishEdit(canvas); return;
    }
    if (activeTool === 'eraser') { eraseAt(page, p, canvas); return; }
    const kind = activeTool;
    draft = { id: id(), page, kind: kind as Annotation['kind'], color: kind === 'redact' ? '#111318' : activeColor, opacity: kind === 'highlight' ? .28 : 1, width: kind === 'signature' ? Math.max(1.6, activeWidth) : activeWidth };
    if (kind === 'pen' || kind === 'signature') draft.points = [p];
    else draft.rect = { x: p.x, y: p.y, w: 0, h: 0 };
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!draft) return; event.preventDefault(); const p = point(event);
    if (draft.points) draft.points.push(p);
    if (draft.rect) { draft.rect.w = p.x - draft.rect.x; draft.rect.h = p.y - draft.rect.y; }
    drawOverlay(canvas, normalizeDraft(draft));
  });
  const finish = () => {
    if (!draft) return;
    const normalized = normalizeDraft(draft);
    const meaningful = normalized.points ? normalized.points.length > 1 : normalized.rect && normalized.rect.w > .006 && normalized.rect.h > .006;
    if (meaningful) {
      if (normalized.kind === 'replace') {
        const replacement = window.prompt('Replacement text (leave blank to cover the area):', '') ?? '';
        normalized.text = replacement; normalized.fontSize = .026;
      }
      checkpoint(); annotations.push(normalized); finishEdit(canvas);
    } else drawOverlay(canvas);
    draft = null;
  };
  canvas.addEventListener('pointerup', finish); canvas.addEventListener('pointercancel', finish);
}

function normalizeDraft(item: Annotation): Annotation {
  if (!item.rect) return item;
  const rect = { ...item.rect };
  if (rect.w < 0) { rect.x += rect.w; rect.w = Math.abs(rect.w); }
  if (rect.h < 0) { rect.y += rect.h; rect.h = Math.abs(rect.h); }
  return { ...item, rect };
}

function eraseAt(page: number, p: { x: number; y: number }, canvas: HTMLCanvasElement) {
  const candidates = annotations.filter((item) => item.page === page).reverse();
  const match = candidates.find((item) => {
    if (item.rect) return p.x >= item.rect.x - .02 && p.x <= item.rect.x + item.rect.w + .02 && p.y >= item.rect.y - .02 && p.y <= item.rect.y + item.rect.h + .02;
    return item.points?.some((q) => Math.hypot(q.x - p.x, q.y - p.y) < .035);
  });
  if (!match) { toast('Tap directly on an edit to erase it'); return; }
  checkpoint(); annotations = annotations.filter((item) => item.id !== match.id); finishEdit(canvas);
}

function finishEdit(canvas: HTMLCanvasElement) {
  saveDraft(); drawOverlay(canvas); updateEditorActions();
}

function redrawAllOverlays() {
  document.querySelectorAll<HTMLCanvasElement>('.page-overlay').forEach((canvas) => drawOverlay(canvas));
}

function updateEditorActions() {
  const undoButton = document.querySelector<HTMLButtonElement>('[data-action="undo"]');
  const redoButton = document.querySelector<HTMLButtonElement>('[data-action="redo"]');
  if (undoButton) undoButton.disabled = !undoStack.length;
  if (redoButton) redoButton.disabled = !redoStack.length;
  const status = document.querySelector('.doc-status span:last-child');
  if (status) status.textContent = annotations.length ? `${annotations.length} unsaved edit${annotations.length === 1 ? '' : 's'}` : 'Viewing original';
}

function showTextDialog(page: number, position: { x: number; y: number }) {
  showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>Add content</span><h2>Text box</h2></div><button data-close>${icon('close')}</button></div>
    <label class="field-label">Text<textarea id="annotation-text" rows="4" placeholder="Type here…" autofocus></textarea></label>
    <div class="field-row"><label class="field-label">Size<select id="annotation-size"><option value=".022">Small</option><option value=".028" selected>Medium</option><option value=".038">Large</option></select></label><label class="field-label">Colour<input id="annotation-color" type="color" value="${activeColor}"></label></div>
    <button class="primary-btn full" data-confirm-text>Add to page</button>`, (modal) => {
      modal.querySelector('[data-confirm-text]')?.addEventListener('click', () => {
        const text = (modal.querySelector<HTMLTextAreaElement>('#annotation-text')?.value ?? '').trim();
        if (!text) { toast('Type some text first'); return; }
        checkpoint(); annotations.push({ id: id(), page, kind: 'text', color: modal.querySelector<HTMLInputElement>('#annotation-color')!.value, opacity: 1, width: 1, text, fontSize: Number(modal.querySelector<HTMLSelectElement>('#annotation-size')!.value), rect: { x: position.x, y: position.y, w: Math.min(.72, 1 - position.x), h: .12 } });
        saveDraft(); closeModal(); redrawAllOverlays(); updateEditorActions();
      });
    });
}

function showModal(content: string, ready?: (modal: HTMLElement) => void, wide = false) {
  closeModal();
  const layer = document.createElement('div'); layer.className = 'modal-layer';
  layer.innerHTML = `<div class="modal-sheet ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${content}</div>`;
  document.body.append(layer); requestAnimationFrame(() => layer.classList.add('open'));
  layer.addEventListener('click', (event) => { if (event.target === layer || (event.target as HTMLElement).closest('[data-close]')) closeModal(); });
  ready?.(layer.querySelector('.modal-sheet')!);
}

function closeModal() {
  const layer = document.querySelector('.modal-layer'); if (!layer) return;
  layer.classList.remove('open'); window.setTimeout(() => layer.remove(), 180);
}

async function showSearch() {
  showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>Find in document</span><h2>Search</h2></div><button data-close>${icon('close')}</button></div>
    <div class="search-box">${icon('search')}<input id="search-input" placeholder="Word or phrase" autocomplete="off"><button id="search-go">Find</button></div><div id="search-results" class="search-results"><div class="search-hint">Search selectable text across all ${engine.pageCount} pages.</div></div>`, (modal) => {
      const run = async () => {
        const input = modal.querySelector<HTMLInputElement>('#search-input')!; const results = modal.querySelector<HTMLElement>('#search-results')!;
        if (!input.value.trim()) return;
        results.innerHTML = '<div class="inline-loading"><div class="spinner"></div>Searching pages…</div>';
        const hits = await engine.search(input.value);
        results.innerHTML = hits.length ? hits.map((hit) => `<button data-jump="${hit.page}"><span class="result-page">${hit.page}</span><span><strong>${hit.count} match${hit.count === 1 ? '' : 'es'}</strong><small>…${safe(hit.preview)}…</small></span>${icon('chevron')}</button>`).join('') : '<div class="search-hint">No selectable text matched. Scanned pages need OCR.</div>';
      };
      modal.querySelector('#search-go')?.addEventListener('click', run); modal.querySelector('#search-input')?.addEventListener('keydown', (event) => { if ((event as KeyboardEvent).key === 'Enter') run(); });
      modal.addEventListener('click', (event) => { const jump = (event.target as HTMLElement).closest<HTMLElement>('[data-jump]'); if (jump) { const page = jump.dataset.jump; closeModal(); document.querySelector(`#page-${page}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); } });
    });
}

async function showPages() {
  const specs: PageSpec[] = Array.from({ length: engine.pageCount }, (_, source) => ({ id: id(), source, rotation: 0, selected: false }));
  const listHtml = () => specs.map((page, index) => `<div class="page-manager-row" data-spec="${page.id}">
      <label><input type="checkbox" data-select ${page.selected ? 'checked' : ''}><span class="checkmark">${icon('check', 15)}</span></label>
      <span class="page-thumb-mini">${page.source + 1}<i style="transform:rotate(${page.rotation}deg)">PDF</i></span>
      <span class="page-manager-name"><strong>Page ${index + 1}</strong><small>Original page ${page.source + 1}${page.rotation ? ` · rotated ${page.rotation}°` : ''}</small></span>
      <div class="page-row-actions"><button data-up aria-label="Move up">${icon('up', 18)}</button><button data-down aria-label="Move down">${icon('down', 18)}</button><button data-rotate aria-label="Rotate">${icon('rotate', 18)}</button><button data-copy aria-label="Duplicate">${icon('copy', 18)}</button><button data-delete aria-label="Delete">${icon('trash', 18)}</button></div>
    </div>`).join('');
  showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>${engine.pageCount} pages</span><h2>Organize pages</h2></div><button data-close>${icon('close')}</button></div>
    <div class="page-manager" id="page-manager">${listHtml()}</div>
    <div class="modal-actions"><button class="soft-btn" data-extract>${icon('share', 18)} Extract selected</button><button class="primary-btn" data-apply-pages>${icon('check', 18)} Apply changes</button></div>`, (modal) => {
      const refresh = () => { modal.querySelector('#page-manager')!.innerHTML = listHtml(); };
      modal.querySelector('#page-manager')?.addEventListener('click', (event) => {
        const row = (event.target as HTMLElement).closest<HTMLElement>('[data-spec]'); if (!row) return;
        const index = specs.findIndex((item) => item.id === row.dataset.spec); if (index < 0) return;
        if ((event.target as HTMLElement).closest('[data-up]') && index > 0) [specs[index - 1], specs[index]] = [specs[index], specs[index - 1]];
        else if ((event.target as HTMLElement).closest('[data-down]') && index < specs.length - 1) [specs[index], specs[index + 1]] = [specs[index + 1], specs[index]];
        else if ((event.target as HTMLElement).closest('[data-rotate]')) specs[index].rotation = (specs[index].rotation + 90) % 360;
        else if ((event.target as HTMLElement).closest('[data-copy]')) specs.splice(index + 1, 0, { ...specs[index], id: id(), selected: false });
        else if ((event.target as HTMLElement).closest('[data-delete]')) { if (specs.length === 1) toast('A PDF needs at least one page'); else specs.splice(index, 1); }
        else return;
        refresh();
      });
      modal.querySelector('#page-manager')?.addEventListener('change', (event) => { const row = (event.target as HTMLElement).closest<HTMLElement>('[data-spec]'); if (row) specs.find((item) => item.id === row.dataset.spec)!.selected = (event.target as HTMLInputElement).checked; });
      modal.querySelector('[data-extract]')?.addEventListener('click', async () => {
        if (!specs.some((page) => page.selected)) { toast('Select at least one page'); return; }
        setBusy(true, 'Extracting pages…'); try { const base = await engine.exportAnnotations(annotations); const bytes = await engine.extractPages(base, specs); await saveBytes(bytes, `Extracted-${engine.name}`, true); } catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); }
      });
      modal.querySelector('[data-apply-pages]')?.addEventListener('click', async () => {
        closeModal(); setBusy(true, 'Rebuilding pages…');
        try { const flattened = await engine.exportAnnotations(annotations); const bytes = await engine.rebuildPages(flattened, specs); annotations = []; undoStack = []; redoStack = []; await engine.load(bytes, engine.name); renderDocument(); toast('Page changes applied', 'success'); }
        catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); }
      });
    }, true);
}

async function showForms() {
  setBusy(true, 'Checking form fields…');
  try {
    const fields = await engine.readFormFields(); setBusy(false);
    if (!fields.length) { toast('No interactive form fields found. Use Edit → Text to fill this PDF.'); activeTool = 'text'; setEditMode(); return; }
    const inputFor = (field: FormFieldInfo) => {
      if (field.type === 'checkbox') return `<input type="checkbox" data-field="${safe(field.name)}" ${field.value ? 'checked' : ''}>`;
      if (field.options.length) return `<select data-field="${safe(field.name)}"><option value="">Choose…</option>${field.options.map((option) => `<option ${option === field.value ? 'selected' : ''}>${safe(option)}</option>`).join('')}</select>`;
      if (field.type === 'unsupported') return '<small>Unsupported button or signature widget</small>';
      return `<input type="text" data-field="${safe(field.name)}" value="${safe(String(field.value))}">`;
    };
    showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>${fields.length} fields detected</span><h2>Fill form</h2></div><button data-close>${icon('close')}</button></div><div class="form-fields">${fields.map((field) => `<label><span>${safe(field.name)}</span>${inputFor(field)}</label>`).join('')}</div><button class="primary-btn full" data-apply-form>Apply form values</button>`, (modal) => {
      modal.querySelector('[data-apply-form]')?.addEventListener('click', async () => {
        const values: Record<string, string | boolean> = {};
        modal.querySelectorAll<HTMLInputElement | HTMLSelectElement>('[data-field]').forEach((input) => { values[input.dataset.field!] = input instanceof HTMLInputElement && input.type === 'checkbox' ? input.checked : input.value; });
        closeModal(); setBusy(true, 'Filling form…');
        try { const bytes = await engine.applyForm(values); await engine.load(bytes, engine.name); renderDocument(); toast('Form values applied', 'success'); } catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); }
      });
    });
  } catch (error) { setBusy(false); toast(messageOf(error), 'error'); }
}

function showMore() {
  showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>Document</span><h2>More options</h2></div><button data-close>${icon('close')}</button></div>
    <div class="menu-list"><button data-menu="save">${icon('save')}<span><strong>Save a copy</strong><small>Keep your original unchanged</small></span>${icon('chevron')}</button><button data-menu="share">${icon('share')}<span><strong>Share edited PDF</strong><small>Send with Android share sheet</small></span>${icon('chevron')}</button><button data-menu="print">${icon('print')}<span><strong>Print</strong><small>Open Android sharing and choose Print</small></span>${icon('chevron')}</button><button data-menu="discard" class="danger">${icon('trash')}<span><strong>Discard unsaved edits</strong><small>Return to the opened PDF</small></span></button></div>`, (modal) => {
      modal.addEventListener('click', async (event) => {
        const item = (event.target as HTMLElement).closest<HTMLElement>('[data-menu]'); if (!item) return; closeModal();
        if (item.dataset.menu === 'save') await exportAndSave(false);
        if (item.dataset.menu === 'share' || item.dataset.menu === 'print') await exportAndSave(true);
        if (item.dataset.menu === 'discard') { if (!annotations.length || window.confirm('Discard all unsaved annotations?')) { annotations = []; undoStack = []; redoStack = []; saveDraft(); redrawAllOverlays(); updateEditorActions(); } }
      });
    });
}

async function exportAndSave(share = false) {
  setBusy(true, 'Preparing edited PDF…');
  try {
    const bytes = await engine.exportAnnotations(annotations);
    const stem = engine.name.replace(/\.pdf$/i, '');
    await saveBytes(bytes, `${stem}-edited.pdf`, share);
    engine.bytes = new Uint8Array(bytes); annotations = []; undoStack = []; redoStack = []; saveDraft(); updateEditorActions();
    toast(share ? 'Ready to share' : 'Choose where to save the copy', 'success');
  } catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); }
}

async function saveBytes(bytes: Uint8Array, filename: string, shareAfter: boolean) {
  const cleanName = filename.replace(/[^a-zA-Z0-9._ -]/g, '_');
  if (Capacitor.isNativePlatform()) {
    const base64 = bytesToDataUrl(bytes).split(',')[1];
    const result = await Filesystem.writeFile({ path: `ClarityPDF/${Date.now()}-${cleanName}`, data: base64, directory: Directory.Cache, recursive: true });
    await Share.share({ title: cleanName, text: shareAfter ? 'PDF edited with Clarity PDF' : 'Choose Files or Drive to save this PDF', files: [result.uri], dialogTitle: shareAfter ? 'Share PDF' : 'Save PDF copy' });
  } else {
    const blob = new Blob([bytes as BlobPart], { type: 'application/pdf' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = cleanName; a.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

function setEditMode() {
  if (activeTool === 'read') activeTool = 'pen';
  document.querySelectorAll('[data-mode]').forEach((button) => button.classList.toggle('active', (button as HTMLElement).dataset.mode === 'annotate'));
  document.querySelector('.annotation-row')?.classList.add('open'); document.querySelector('.edit-options')?.classList.add('open');
  document.querySelectorAll('[data-edit-tool]').forEach((button) => button.classList.toggle('active', (button as HTMLElement).dataset.editTool === activeTool));
  document.querySelectorAll('.page-overlay').forEach((overlay) => overlay.classList.add('editing'));
}

function setReadMode() {
  activeTool = 'read';
  document.querySelectorAll('[data-mode]').forEach((button) => button.classList.toggle('active', (button as HTMLElement).dataset.mode === 'read'));
  document.querySelector('.annotation-row')?.classList.remove('open'); document.querySelector('.edit-options')?.classList.remove('open'); document.querySelectorAll('.page-overlay').forEach((overlay) => overlay.classList.remove('editing'));
}

function showThemePicker() {
  showModal(`<div class="modal-grabber"></div><div class="modal-title"><div><span>Appearance</span><h2>Choose theme</h2></div><button data-close>${icon('close')}</button></div><div class="choice-list">${(['system', 'light', 'dark'] as const).map((value) => `<button data-choice="${value}" class="${settings.theme === value ? 'selected' : ''}"><span>${value === 'system' ? 'Use phone setting' : value[0].toUpperCase() + value.slice(1)}</span>${settings.theme === value ? icon('check') : ''}</button>`).join('')}</div>`, (modal) => {
    modal.addEventListener('click', (event) => { const choice = (event.target as HTMLElement).closest<HTMLElement>('[data-choice]'); if (!choice) return; settings.theme = choice.dataset.choice as AppSettings['theme']; persistSettings(); closeModal(); renderSettings(); });
  });
}

function persistSettings() { store.set('clarity.settings', settings); applyTheme(); }
const messageOf = (error: unknown) => error instanceof Error ? error.message : 'Something went wrong';

async function checkIncomingPdf() {
  if (!Capacitor.isNativePlatform() || isBusy) return;
  try {
    const incoming = await IncomingPdf.getIncoming();
    if (!incoming.path) return;
    setBusy(true, 'Opening shared PDF…');
    const response = await fetch(Capacitor.convertFileSrc(`file://${incoming.path}`));
    const blob = await response.blob();
    await openFile(new File([blob], incoming.name || 'Shared-Document.pdf', { type: 'application/pdf', lastModified: Date.now() }));
  } catch { toast('The shared PDF could not be opened', 'error'); }
  finally { setBusy(false); }
}

app.addEventListener('click', async (event) => {
  if (isBusy) return;
  const target = event.target as HTMLElement;
  const nav = target.closest<HTMLElement>('[data-nav]');
  if (nav) { const page = nav.dataset.nav; if (page === 'home') renderHome(); if (page === 'tools') renderTools(); if (page === 'settings') renderSettings(); return; }
  const action = target.closest<HTMLElement>('[data-action]')?.dataset.action;
  if (action === 'open') pdfPicker.click();
  if (action === 'sample') { setBusy(true, 'Creating sample…'); try { await openGenerated(await PdfEngine.sample(), 'Clarity-PDF-Sample.pdf'); } finally { setBusy(false); } }
  if (action === 'clear-recents') { recents = []; store.set('clarity.recents', recents); renderHome(); }
  if (action === 'back') { if (!annotations.length || window.confirm('Leave this document? Unfinished annotations will be remembered.')) { engine.close(); renderHome(); } }
  if (action === 'search') showSearch();
  if (action === 'more') showMore();
  if (action === 'pages') showPages();
  if (action === 'forms') showForms();
  if (action === 'save') exportAndSave(false);
  if (action === 'undo') undo();
  if (action === 'redo') redo();
  const recent = target.closest<HTMLElement>('[data-recent]'); if (recent) { toast('For privacy, choose the same file again to reopen it.'); pdfPicker.click(); }
  const tool = target.closest<HTMLElement>('[data-tool]')?.dataset.tool;
  if (tool === 'merge') multiPdfPicker.click();
  if (tool === 'images') multiImagePicker.click();
  if (tool === 'blank') { setBusy(true, 'Creating blank PDF…'); try { await openGenerated(await PdfEngine.blank(), 'Blank-Document.pdf'); } finally { setBusy(false); } }
  const mode = target.closest<HTMLElement>('[data-mode]')?.dataset.mode; if (mode === 'read') setReadMode(); if (mode === 'annotate') setEditMode();
  const editTool = target.closest<HTMLElement>('[data-edit-tool]')?.dataset.editTool as Tool | undefined;
  if (editTool) { activeTool = editTool; setEditMode(); if (editTool === 'image') imagePicker.click(); }
  const ink = target.closest<HTMLElement>('[data-ink]')?.dataset.ink; if (ink) { activeColor = ink; document.querySelectorAll('[data-ink]').forEach((item) => item.classList.toggle('active', (item as HTMLElement).dataset.ink === ink)); }
  const setting = target.closest<HTMLElement>('[data-setting]')?.dataset.setting; if (setting === 'theme') showThemePicker(); if (setting === 'gap') { settings.pageGap = settings.pageGap === 'compact' ? 'comfortable' : 'compact'; persistSettings(); renderSettings(); }
});

app.addEventListener('input', (event) => {
  const target = event.target as HTMLInputElement;
  if (target.matches('[data-width]')) activeWidth = Number(target.value);
  if (target.matches('[data-toggle="drafts"]')) { settings.rememberDrafts = target.checked; persistSettings(); }
  if (target.matches('[data-color="ink"]')) { settings.defaultInk = target.value; activeColor = target.value; persistSettings(); }
});

pdfPicker.addEventListener('change', () => { if (pdfPicker.files?.[0]) openFile(pdfPicker.files[0]); });
multiPdfPicker.addEventListener('change', async () => {
  const files = Array.from(multiPdfPicker.files ?? []); if (!files.length) return; setBusy(true, 'Merging PDFs…');
  try { const bytes = await PdfEngine.merge(files); await openGenerated(bytes, `Merged-${Date.now()}.pdf`); toast(`${files.length} PDFs merged`, 'success'); } catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); multiPdfPicker.value = ''; }
});
multiImagePicker.addEventListener('change', async () => {
  const files = Array.from(multiImagePicker.files ?? []); if (!files.length) return; setBusy(true, 'Creating PDF from images…');
  try { const bytes = await PdfEngine.imagesToPdf(files); await openGenerated(bytes, `Images-${Date.now()}.pdf`); toast(`${files.length} image${files.length === 1 ? '' : 's'} added`, 'success'); } catch (error) { toast(messageOf(error), 'error'); } finally { setBusy(false); multiImagePicker.value = ''; }
});
imagePicker.addEventListener('change', () => {
  const file = imagePicker.files?.[0]; if (!file) return;
  const reader = new FileReader(); reader.onload = () => { pendingImage = String(reader.result); toast('Now tap the page to place the image'); }; reader.readAsDataURL(file); imagePicker.value = '';
});

window.addEventListener('popstate', () => { if (document.querySelector('.modal-layer')) closeModal(); else if (screen === 'document') renderHome(); });
window.addEventListener('clarity-incoming-ready', checkIncomingPdf);
window.addEventListener('focus', checkIncomingPdf);

applyTheme();
renderHome();
window.setTimeout(checkIncomingPdf, 500);
