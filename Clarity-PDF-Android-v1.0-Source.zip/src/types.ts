export type Tool = 'read' | 'pen' | 'highlight' | 'text' | 'replace' | 'redact' | 'signature' | 'image' | 'eraser';

export type Point = { x: number; y: number };

export type Annotation = {
  id: string;
  page: number;
  kind: Exclude<Tool, 'read' | 'eraser'>;
  color: string;
  opacity: number;
  width: number;
  points?: Point[];
  rect?: { x: number; y: number; w: number; h: number };
  text?: string;
  fontSize?: number;
  imageData?: string;
};

export type RecentFile = {
  name: string;
  size: number;
  openedAt: number;
  pages: number;
  fingerprint: string;
};

export type PageSpec = {
  id: string;
  source: number;
  rotation: number;
  selected: boolean;
};

export type AppSettings = {
  theme: 'light' | 'dark' | 'system';
  pageGap: 'compact' | 'comfortable';
  keepScreenAwake: boolean;
  rememberDrafts: boolean;
  defaultInk: string;
};

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'system',
  pageGap: 'comfortable',
  keepScreenAwake: false,
  rememberDrafts: true,
  defaultInk: '#E5484D',
};
