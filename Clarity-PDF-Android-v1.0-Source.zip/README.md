# Clarity PDF for Android

Clarity PDF is an offline-first PDF reader and practical editor designed for phones and tablets. It has no ads, account requirement, analytics, or document upload server.

## Included features

- Open PDFs from the app, Android Files, email, WhatsApp, Drive, or another app's “Open with” menu.
- Smooth page rendering, scrolling, zooming, page counter, recent-file metadata, and full-document text search.
- Pen, highlighter, text box, visual text replacement, permanent black redaction, handwritten signature, image insertion, and eraser.
- Undo/redo and recovery of unfinished annotations for the same local file.
- Interactive PDF form detection and filling.
- Reorder, rotate, duplicate, delete, or extract pages.
- Merge multiple PDFs, convert JPG/PNG images to A4 PDF, and create a blank PDF.
- Save the edited document as a new copy or send it through Android's share sheet.
- Light, dark, and phone-controlled themes.
- Password prompt for viewing protected PDFs.

## Important editing boundary

This app can add, cover, replace visually, redact, annotate, fill, sign, and reorganize PDF content. It does not claim universal paragraph reflow or OCR conversion of scanned text. True font-matched editing of arbitrary embedded PDF text and OCR of scans requires a much larger OCR/layout engine and is not reliable in a small offline open-source app.

## Build the APK without command line

See [MOBILE_BUILD_GUIDE.md](MOBILE_BUILD_GUIDE.md). The included GitHub Actions workflow builds an installable APK automatically.

## Privacy

The Android manifest intentionally requests no Internet permission. The app reads the files selected by the user and writes exported copies to its cache before showing Android's save/share chooser. Recent items contain only filename, size, page count, and time opened—not the document itself.

## Technology

- Capacitor 8 Android shell
- Mozilla PDF.js for local rendering and text extraction
- pdf-lib for PDF creation, annotations, forms, page operations, and export
- TypeScript and Vite

PDF.js is licensed under Apache-2.0. pdf-lib is licensed under MIT. See the dependency packages for their full license texts.
